#include <iostream>
#include <time.h>
#include <math.h>
#include <fstream>

using namespace std;

void enunciado()
{
    cout<<endl<<endl<<endl;

    cout<<"Ejercicio 1"<<endl;

    cout<<"Ejercicio 2"<<endl;

    cout<<"Ejercicio 3"<<endl;

    cout<<"Ingrese 0 para salir"<<endl;

}

void piramide_de_estrellas(ofstream & fout)

{

    //Crear una funcion que tome un entero n y que imprima recursivamente una piramide de base n, como se puede ver en la siguiente imagen
//para n = 5.

int n;
cout<<"Ingrese un n para crear la piramide"<<endl;

fout<<"Ingrese un n para crear la piramide"<<endl;

cin>>n;
cout<<"La piramide sera de base "<<n<<endl;

fout<<"La piramide sera de base "<<n<<endl;
string p="*";


for(int i=1;i<=n;i++)
{

    cout<<p<<endl;
    fout<<p<<endl;
    p=p+"  *  ";

}


}


int invertirdigitos(int num, int inver = 0) {

    if (num == 0) {
        return inver;
    }
    int digito = num % 10;
    inver = inver * 10 + digito;
    return invertirdigitos(num / 10, inver);
}


bool palindromo(int num) {

    int numeroinvertido = invertirdigitos(num);

    if (num == numeroinvertido) {
        return true;
    } else {
        return false;
    }
}
void printDigits(int number) {
    if (number < 10) {
        cout << number << " ";
    } else {
        printDigits(number / 10);
        cout << number % 10 << " ";
    }
}
int suma(int a, int b)
{
    int r;
    r=a+b;
    return r;
}

int resta(int a, int b)
{
    int r;
    r=a-b;
    return r;
}

void imprimir_mensaje ()
{
 cout << "Taller de Programacion"<<endl;
}

void imprimir_encabezado()
{
    cout<<"**********"<<endl;
    cout<<"Funciones iterativas y valores por defecto"<<endl;
    cout<<"14  de julio de 2023"<<endl;
    cout<<"**********"<<endl;
    cout<<"Integrantes:"<<endl;
cout<<"Luis Antonio Burgos"<<endl;
cout<<"Christhoper Almeida"<<endl;
cout<<"Alejandra Rodriguez"<<endl;


}

int leer_numero_no_negativo( )
{
   int n;
   do
   {
       cout<<"Ingrese un numero entero mayor o igual a cero"<<endl;
       cin>>n;
   }
   while(n<0);

   return n;
}

double factorial(int n)
{
    double f=1;
    if(n==0) return f;
    else
    {
        for(int i=1; i<=n; i++)
            f=f*i;
    }
    return f;
}

double coeficiente_binomial(int n, int k)
{
    double cb;
    cb=factorial(n)/(factorial (k)*factorial(n-k));
    return cb;
}

int aleatorio_entre(int a, int b)
{
    int x=a+rand()%(b+1-a);
    return x;
}

double Fahrenheit(double C){
double F=9.0/5*C+32;
return F;
}

double sin(double x, int N){
    double s=0;
    for(int n=0;n<=N;n++){
        s+=(pow(-1.0,n)/factorial(2*n+1))*pow(x,2*n+1);
    }
    return s;
}

double cos(double x,int N){
    double c=0;
    for(int n=0;n<=N;n++){
        c+=(pow(-1.0,n)/factorial(2*n))*pow(x,2*n);
    }
    return c;
}
