#include <iostream>
#include <time.h>
#include "global.h" //conecta los archivos global.h y .cpp al programa main.cpp
#include <fstream>
using namespace std;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main()
{

int opcion;
imprimir_mensaje();
imprimir_encabezado();
 do
{
enunciado();


    cin>>opcion;
    switch(opcion)
    {


    case 1:


        {
            cout<<endl<<endl;
      cout<<"Ejercicio 1: Crear una funcion que tome un valor entero e imprima de forma recursiva"<<endl;
           int number;
           cout<<"Ingrese un numero"<<endl;
           cin>>number;

           cout << "Digits: ";
    printDigits(number);
    cout << endl;
        }

        break;


    case 2:
        {
cout<<endl<<endl;

cout<<"Ejercicio 2:"<<endl<<endl;

    cout<<"2.1: Tomar un n entero y devolverlo invertido"<<endl;


int n;
cout<<"Ingrese un n"<<endl;
cin>>n;
cout<<endl;

    int numInvertido = invertirdigitos(n);
    cout << "El numero invertido de " << n << " es: " << numInvertido << endl;
    cout<<endl<<endl;

    cout<<"2.2: Verificar si un numero es palindromo"<<endl;

    int s;
    cout<<"Ingrese un numero"<<endl;
    cin>>s;

    if (palindromo(s)==true) {
        cout << s << " es un palindromo." << endl;
    } else {
        cout << s << " no es un palindromo." <<endl;
    }

        }
        break;


    case 3:
        {
   ofstream fout;
   fout.open("Piramide");
   piramide_de_estrellas(fout);
   fout.close ();
        }
        break;


    }

}

 while(opcion!=0);


    return 0;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
