#ifndef GLOBAL_H_INCLUDED
#define GLOBAL_H_INCLUDED

using namespace std;

int suma(int a, int b); //DECLARAR FUNCIONES
int resta(int a, int b);
void imprimir_mensaje ();
void imprimir_encabezado();
int leer_numero_no_negativo();
double factorial(int n);
double coeficiente_binomial(int n, int k);
int aleatorio_entre(int a, int b);
double Fahrenheit(double C);
double sin(double x, int N);
double cos(double x,int N);
int invertirdigitos(int num, int inver = 0);
bool palindromo(int num);
void printDigits(int number);
void piramide_de_estrellas(ofstream & fout);
void enunciado();
#endif // GLOBAL_H_INCLUDED
